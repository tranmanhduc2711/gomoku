import Game from './components/Game';
import './App.css';

function App() {
  return (
    <div>
      <Game />
    </div>
  );
}

export default App;
